package co.edu.unbosque.controller;

public class Aplmain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		controller c = new controller();
	}

}
